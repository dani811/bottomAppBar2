package com.becody.bottombar;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView countryListing = findViewById(R.id.countryListing);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        countryListing.setLayoutManager(layoutManager);
        CountryAdapter countryAdapter = new CountryAdapter(fetchCountryInfo());
        countryListing.setAdapter(countryAdapter);
    }

    private List<Country> fetchCountryInfo() {
        List<Country> countryList = new ArrayList<>();
        String[] arrName = getResources().getStringArray(R.array.arr_countries);
        String[] arrDescription = getResources().getStringArray(R.array.arr_countries_description);
        for (int i = 0; i < arrName.length; i++) {
            Country country = new Country();
            country.setName(arrName[i]);
            country.setDescription(arrDescription[i]);
            countryList.add(country);
        }
        return countryList;
    }
}
